package shopping.gogreen.services;

import java.sql.Date;

import shopping.gogreen.domain.ContactUs;
import shopping.gogreen.domain.User;

/**
 * These are the services provided by the server side
 */

public interface UserService {

	public void insertData(User user);

	public String getUser(String email, String password);

	public boolean checkDuplicateEntries(String email, Long mobile);

	public String forgotPassword(String email, String securityAnswer);

	public void setNewPassword(String string, String string2);

	public User getUserDetails(String email);

	public String getPassword(String email);

	public void updateMobile(String email, long mobile);

	public void insertComplaints(ContactUs contactUs);

	public byte[] getSalt(String email);

	public Date getServerDate();

}