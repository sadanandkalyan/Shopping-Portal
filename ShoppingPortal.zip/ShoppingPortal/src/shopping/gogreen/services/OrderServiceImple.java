package shopping.gogreen.services;

import shopping.gogreen.dao.OrderDao;
import shopping.gogreen.domain.Order;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * service implementation that calls the OrderDao implementation
 */
public class OrderServiceImple implements OrderService {

	@Autowired
	OrderDao orderDao;

	/**
	 * insertOrder method that calls the dao implementation of insertOrder
	 * method
	 */
	@Override
	public void insertOrder(Order order) {
		orderDao.insertOrder(order);
	}

	/**
	 * getOrderID method that calls the dao implementation of getOrderID method
	 */
	@Override
	public int getOrderID(int productID, String email) {
		return orderDao.getOrderID(productID, email);
	}

	/**
	 * getOrderDetails method that calls the dao implementation of
	 * getOrderDetails method
	 */
	@Override
	public List<Order> getOrderDetails(String email) {
		return orderDao.getOrderDetails(email);
	}

}
