package shopping.gogreen.services;

import java.util.List;

import shopping.gogreen.domain.Cart;

/**
 * These are the services provided by the server side
 */
public interface CartService {

	public List<Cart> getCart(String email);

	public void removeCartWithEmail(String email);

	public void addToCart(int productID, String email);

	public int getCartCount(String email);

	public void removeCart(int productID);

}
