package shopping.gogreen.services;

import java.util.List;

import shopping.gogreen.domain.Products;

/**
 * These are the services provided by the server side
 */
public interface ProductService {

	public List<Products> getProductList();

	public Products getSingleProductDetails(int productID);

	public List<Products> getCategoryList(String category);

	public List<Products> search(String search);

	public List<Integer> getProductsId();

	public int getQuantity(int productID);

	public void increaseQuantity(int productID);

	public boolean decreaseQuantity(int productID);

}
