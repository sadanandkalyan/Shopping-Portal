package shopping.gogreen.services;

import java.util.List;

import shopping.gogreen.domain.Order;

/**
 * These are the services provided by the server side
 */
public interface OrderService {

	public void insertOrder(Order order);

	public int getOrderID(int productID, String email);

	public List<Order> getOrderDetails(String email);

}
