package shopping.gogreen.services;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;

import shopping.gogreen.dao.UserDao;
import shopping.gogreen.domain.ContactUs;
import shopping.gogreen.domain.User;

/**
 * Service implementation that calls the UserDao implementation
 */
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userdao;

	/**
	 * InsertData method that calls the dao implementation of insertData method
	 */
	@Override
	public void insertData(User user) {
		userdao.insertData(user);
	}

	/**
	 * getUser method that calls the dao implementation of getUser method
	 */
	@Override
	public String getUser(String email, String password) {
		return userdao.getUser(email, password);
	}

	/**
	 * checkDuplicateEntries method that calls the dao implementation of
	 * checkDuplicateEntries method
	 */
	@Override
	public boolean checkDuplicateEntries(String email, Long mobile) {
		return userdao.checkDuplicateEntries(email, mobile);
	}

	/**
	 * forgotPassword method that calls the dao implementation of forgotPassword
	 * method
	 */
	@Override
	public String forgotPassword(String email, String securityAnswer) {
		return userdao.forgotPassword(email, securityAnswer);
	}

	/**
	 * setNewPassword method that calls the dao implementation of setNewPassword
	 * method
	 */
	@Override
	public void setNewPassword(String password, String email) {
		userdao.setNewPassword(password, email);
	}

	/**
	 * getUserDetails method that calls the dao implementation of getUserDetails
	 * method
	 */
	@Override
	public User getUserDetails(String email) {
		return userdao.getUserDetails(email);
	}

	/**
	 * getPassword method that calls the dao implementation of getPassword
	 * method
	 */
	@Override
	public String getPassword(String email) {
		return userdao.getPassword(email);
	}

	/**
	 * updateMobile method that calls the dao implementation of updateMobile
	 * method
	 */
	@Override
	public void updateMobile(String email, long mobile) {
		userdao.updateMobile(email, mobile);
	}

	/**
	 * insertComplaints method that calls the dao implementation of
	 * insertComplaints method
	 */
	@Override
	public void insertComplaints(ContactUs contactUs) {
		userdao.insertComplaints(contactUs);
	}

	/**
	 * getSalt method that calls the dao implementation of getSalt method
	 */
	@Override
	public byte[] getSalt(String email) {
		return userdao.getSalt(email);
	}

	/**
	 * getServerDate method that calls the dao implementation of getServerDate
	 * method
	 */
	@Override
	public Date getServerDate() {
		return userdao.getServerDate();
	}

}