package shopping.gogreen.services;

import shopping.gogreen.dao.CartDao;
import shopping.gogreen.domain.Cart;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * service implementation that calls the CartDao implementation
 */
public class CartServiceImpl implements CartService {

	@Autowired
	CartDao cartDao;

	/**
	 * addToCart method that calls the dao implementation of addToCart method
	 */
	@Override
	public void addToCart(int productID, String email) {
		cartDao.addToCart(productID, email);
	}

	/**
	 * getCartCount method that calls the dao implementation of getCartCount
	 * method
	 */
	@Override
	public int getCartCount(String email) {
		return cartDao.getCartCount(email);
	}

	/**
	 * removeCart method that calls the dao implementation of removeCart method
	 */
	@Override
	public void removeCart(int productID) {
		cartDao.removeCart(productID);

	}

	/**
	 * getCart method that calls the dao implementation of getCart method
	 */
	@Override
	public List<Cart> getCart(String email) {
		return cartDao.getCart(email);
	}

	/**
	 * removeCartWithEmail method that calls the dao implementation of
	 * removeCartWithEmail method
	 */
	@Override
	public void removeCartWithEmail(String email) {
		cartDao.removeCartWithEmail(email);

	}

}
