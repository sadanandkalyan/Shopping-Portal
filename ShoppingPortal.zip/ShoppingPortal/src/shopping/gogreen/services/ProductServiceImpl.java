package shopping.gogreen.services;

import shopping.gogreen.dao.ProductDao;
import shopping.gogreen.domain.Products;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * service implementation that calls the productDao implementation
 */
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao productDao;

	/**
	 * getProductList method that calls the dao implementation of getProductList
	 * method
	 */
	@Override
	public List<Products> getProductList() {
		return productDao.getProductsList();
	}

	/**
	 * getSingleProductDetails method that calls the dao implementation of
	 * getSingleProductDetails method
	 */
	@Override
	public Products getSingleProductDetails(int productID) {
		return productDao.getSingleProductDetails(productID);
	}

	/**
	 * getCategoryList method that calls the dao implementation of
	 * getCategoryList method
	 */
	@Override
	public List<Products> getCategoryList(String category) {
		return productDao.getCategoryList(category);
	}

	/**
	 * search method that calls the dao implementation of search method
	 */
	@Override
	public List<Products> search(String search) {
		return productDao.search(search);
	}

	/**
	 * getProductsId method that calls the dao implementation of getProductsId
	 * method
	 */
	@Override
	public List<Integer> getProductsId() {
		return productDao.getProductsId();
	}

	/**
	 * getQuantity method that calls the dao implementation of getQuantity
	 * method
	 */
	@Override
	public int getQuantity(int productID) {
		return productDao.getQuantity(productID);
	}

	/**
	 * decreaseQuantity method that calls the dao implementation of
	 * decreaseQuantity method
	 */
	@Override
	public boolean decreaseQuantity(int productID) {
		return productDao.decreaseQuantity(productID);
	}

	/**
	 * increaseQuantity method that calls the dao implementation of
	 * increaseQuantity method
	 */
	@Override
	public void increaseQuantity(int productID) {
		productDao.increaseQuantity(productID);

	}
}
