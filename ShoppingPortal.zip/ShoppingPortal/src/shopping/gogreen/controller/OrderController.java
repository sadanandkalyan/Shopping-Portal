package shopping.gogreen.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Cart;
import shopping.gogreen.domain.Order;
import shopping.gogreen.domain.Products;
import shopping.gogreen.services.CartService;
import shopping.gogreen.services.OrderService;
import shopping.gogreen.services.ProductService;

/**
 * OrderController.java : It controls the redirections from the Order's Page to
 * another JSP page and do the appropriate functions based on the
 * RequestMapping.
 */
@Controller
public class OrderController {

	@Autowired
	ProductService productService;

	@Autowired
	OrderService orderService;

	@Autowired
	CartService cartService;

	@Resource(name = "list")
	List<Integer> productlist;

	@Autowired
	WebApplicationContext context;

	/**
	 * After the customer has entered the payment details, it will first check
	 * the quantity of the products, since another customer has brought the same
	 * product and quantity may be 0.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 */

	@PostMapping("/paymentForm")
	public String cardValidate(HttpServletRequest request, HttpSession session, Model model) {

		String spid = request.getParameter("productID");

		Order order = getOrder();
		String uname = (String) session.getAttribute("uname");
		String email = (String) session.getAttribute("email");

		// if user has logged in the following block gets executed
		if (uname != null && email != null && spid != null) {

			// if user press checkout this block gets executed
			if (spid.equals("cart") && !spid.equals("error")) {

				// synchronizing session
				synchronized (session) {
					uname = (String) session.getAttribute("uname");
					email = (String) session.getAttribute("email");
					if (uname != null && email != null) {

						// getting cart of user
						List<Cart> cart = cartService.getCart(email);

						Integer vari = 1;
						int i;
						// if cart is not empty
						if (cart.size() > 0) {
							for (i = 0; i < cart.size() && vari > 0; i++) {

								vari = 1;
								Integer j = 0;
								// getting productid index that user wants to
								// buy from productlist
								while (productlist.get(j) != cart.get(i).getProductID() && j < productlist.size()) {

									j++;

								}
								// if productid is not present in productlist
								// then adding it
								if (j == productlist.size()) {
									synchronized (productlist) {
										productlist.add(cart.get(i).getProductID());
									}
								}

								if (productlist.get(j) == cart.get(i).getProductID()) {
									int orderID = orderService.getOrderID(productlist.get(j), email);

									if ((orderID) != 0) {

										// remove from cart if product is
										// already bought
										cartService.removeCart(productlist.get(j));
										vari = 0;

									}

									if (vari > 0) {
										// synchronizing the product that user
										// wants to buy
										synchronized (productlist.get(j)) {

											Integer pids = productlist.get(j);
											orderID = orderService.getOrderID(productlist.get(j), email);
											if ((orderID) != 0) {
												// remove from cart if product
												// is already bought
												cartService.removeCart(productlist.get(j));
												vari = 0;
											}

											if (productService.getQuantity(pids) > 0 && vari > 0) {

												// decreasing the product
												// quantity by 1
												vari = productService.decreaseQuantity(pids) ? 1 : 0;

											} else
												vari = 0;// quantity=0

										}
									}
								} else
									vari = 0;// not found in list
							}
						} else {
							session.setAttribute("cartEmpty", true);
							return "redirect:/cart";
						}
						// if some error occurred from above this block gets
						// executed
						if (vari == 0) {
							for (int m = 0; m < i - 1; m++) {
								Integer j = 0;

								while (j < productlist.size() && productlist.get(j) != cart.get(m).getProductID()) {

									j++;
								}
								if (productlist.get(j) == cart.get(m).getProductID()) {
									synchronized (productlist.get(j)) {

										if (productService.getQuantity(productlist.get(j)) >= 0) {

											// incrementing the products
											// quantity in the cart that are
											// bought partially
											productService.increaseQuantity((productlist.get(j)));

										}

									}
								}
							}
						}
						// if every item in the cart got bought then orders are
						// stored in database
						if (i == cart.size() && vari > 0) {
							List<Order> orderList = getOrderList();
							orderList.clear();
							List<Products> productList = getProductList();
							productList.clear();
							for (int n = 0; n < cart.size(); n++) {
								Products product = productService
										.getSingleProductDetails(((cart.get(n).getProductID())));
								order = orderSuccess(cart.get(n).getProductID(), email, request.getParameter("ship"));

								orderList.add(order);
								productList.add(product);
								cartService.removeCart(cart.get(n).getProductID());

							}
							model.addAttribute("productList", productList);
							model.addAttribute("orderList", orderList);
							int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
							model.addAttribute("cartSize", cartSize);
							return "OrderSuccess";
						}
					} else
						return "OrderFail";
				}
				return "OrderFail";
			}

			else if (spid.equals("error") && !spid.equals("cart")) {

				return "OrderFail";
			}
			// if user press buy now this block gets executed
			else if (!spid.equals("cart") && !spid.equals("error")) {
				int pid = Integer.parseInt(request.getParameter("productID"));

				int quantity1 = productService.getQuantity(pid);
				if (quantity1 > 0) {
					int i = 0;
					// System.out.println("coming here");

					// getting productid index that user wants to buy from
					// productlist
					if (productlist.size() > 0) {

						while (i < productlist.size() && productlist.get(i) != (pid)) {
							i++;
						}
						if (i == productlist.size()) {
							synchronized (productlist) {
								productlist.add(pid);
							}
						}

						// got the product
						if (productlist.get(i) == (pid)) {

							int orderID = orderService.getOrderID(productlist.get(i), email);
							if ((orderID) != 0) {

								return "ReOrder";
							}
							// synchronizing the product that user wants to buy
							synchronized (productlist.get(i)) {

								pid = (productlist.get(i));
								orderID = orderService.getOrderID(productlist.get(i), email);
								// if user has already bought the product not
								// allowing him to buy
								if ((orderID) != 0) {

									return "ReOrder";
								}

								if (productService.getQuantity(pid) > 0) {

									// decreasing the quantity of the product
									boolean var = productService.decreaseQuantity(pid);

									// if buying is successful then creating
									// order and storing it in database
									if (var) {
										List<Order> orderList = getOrderList();
										orderList.clear();
										List<Products> productList = getProductList();
										productList.clear();

										Products product = productService.getSingleProductDetails(pid);

										order = orderSuccess(pid, email, request.getParameter("ship"));

										orderList.add(order);
										productList.add(product);

										model.addAttribute("productList", productList);
										model.addAttribute("orderList", orderList);

										int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
										model.addAttribute("cartSize", cartSize);

										return "OrderSuccess";
									}

								} else
									return "OrderFail";
							}

						}

						else
							return "OrderFail";

					}

					else
						return "OrderFail";
				}

				else
					return "OrderFail";
			} else
				return "OrderFail";
		}
		return "OrderFail";
	}

	public Order orderSuccess(int productID, String email, String ship) {

		Order order = getOrder();

		DateFormat df = new SimpleDateFormat("dd/MM/yy");
		Date date = new Date();
		order.setDateOfBooking(df.format(date));

		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 3);
		date = c.getTime();
		String deliveryDate = df.format(date);
		order.setDeliveryDate(deliveryDate);

		Products product = productService.getSingleProductDetails(productID);
		float price = product.getPrice();
		int discount = product.getDiscount();
		price = (price - price / discount);

		order.setEmail(email);
		order.setProductID(productID);
		order.setAmountPaid(price);
		order.setShippingAddress(ship);

		orderService.insertOrder(order);
		int orderID;

		orderID = orderService.getOrderID(productID, email);

		order.setOrderID(orderID);
		return order;
	}

	@SuppressWarnings("unchecked")
	public List<Order> getOrderList() {
		return (List<Order>) context.getBean("orderList");
	}

	@SuppressWarnings("unchecked")
	public List<Products> getProductList() {
		return (List<Products>) context.getBean("productList");
	}

	public Order getOrder() {
		return (Order) context.getBean("order");
	}

}
