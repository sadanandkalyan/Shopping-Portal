package shopping.gogreen.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import shopping.gogreen.domain.Products;
import shopping.gogreen.services.CartService;
import shopping.gogreen.services.ProductService;

/**
 * HomeController.java : Welcome page Requests are mapped in this Controller.
 */

@Controller
public class HomeController {

	@Autowired
	ProductService productService;

	@Autowired
	CartService cartService;

	/**
	 * All the requests are mapped to this method. Here it will redirect to the
	 * "welcome.jsp" page.
	 * 
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * 
	 * @param session
	 *            To set and get the attributes.
	 * @return welcome It will redirect to that JSP page.
	 */

	@RequestMapping("/")
	public String showMyPage(Model model, HttpSession session) {

		String email = (String) session.getAttribute("email");
		// this attribute is used to notify user that his login is successful
		if (session.getAttribute("loginSuccess") != null) {
			model.addAttribute("loginSuccess", true);
			session.removeAttribute("loginSuccess");
		}
		// this attribute is used to notify user that logout is successful
		if (session.getAttribute("checkLogOut") != null) {
			model.addAttribute("checkLogOut", true);
			session.removeAttribute("checkLogOut");
		}
		// this attribute is used to notify user that cannot check out with
		// empty cart
		if (session.getAttribute("checkOutIfEmpty") != null) {
			model.addAttribute("checkOutIfEmpty", true);
			session.removeAttribute("checkOutIfEmpty");
		}
		// this attribute is used to notify user that he cannot add same product
		// twice to the cart
		if (session.getAttribute("sameProduct") != null) {
			model.addAttribute("sameProduct", true);
			session.removeAttribute("sameProduct");
		}
		// this attribute is used to notify user that compliant is submitted
		if (session.getAttribute("submitContactForm") != null) {
			model.addAttribute("submitContactForm", true);
			session.removeAttribute("submitContactForm");
		}
		// adding cartsize to the model if user has logged in.
		if (session.getAttribute("email") != null) {
			model.addAttribute("cartSize", cartService.getCartCount(email));
		}
		// this attribute is used to notify user that product has been added to
		// the cart
		if (session.getAttribute("addedToCart") != null) {
			model.addAttribute("addedToCart", true);
			session.removeAttribute("addedToCart");
		}

		// adding user name to the model
		model.addAttribute("uname", session.getAttribute("uname"));
		// get products from the database
		List<Products> productList = productService.getProductList();
		// adding productList to the model
		model.addAttribute("productList", productList);
		return "welcome";
	}

	/**
	 * when the request comes for the About Page, It will redirect to that JSP
	 * page. Since we cannot call the JSP page from a JSP page.
	 * 
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * 
	 * @param session
	 *            To set and get the attributes.
	 * 
	 * @return About It will redirect to that JSP page.
	 */
	@RequestMapping("/About")
	public String aboutPage(Model model, HttpSession session) {
		// adding cartsize to the model if user has logged in.
		if ((session.getAttribute("uname") != null) && (session.getAttribute("email") != null)) {
			int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
			model.addAttribute("cartSize", cartSize);
		}
		return "About";
	}

	/**
	 * It will redirect to the Welcome page.
	 * 
	 * @param session
	 *            To set and get the attributes.
	 * 
	 * @return welcome It will redirect to that JSP page.
	 */
	@RequestMapping("/welcome")
	public String welcomePage(HttpSession session) {
		return "redirect:/";
	}

	/**
	 * If the user has chosen the option "forgot password", it will redirect to
	 * the "ForgotPassword" JSP page.
	 * 
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @return String it will redirect to ForgotPassword page.
	 */
	@PostMapping("getForgotPassword")
	public String forgotPassword(HttpSession session, Model model) {

		if (session.getAttribute("passwordMismatch") != null) {
			model.addAttribute("passwordMismatch", true);
			session.removeAttribute("passwordMismatch");
		}
		return "ForgotPassword";
	}

	/**
	 * If the order Fails due to Products Out of Stock, it will redirect to the
	 * "OrderFail" JSP page
	 * 
	 * @return String it will redirect to OrderFail page.
	 */
	@RequestMapping("OrderFail")
	public String orderFail() {
		return "OrderFail";
	}

	/**
	 * If any error occurs in the JSP page, due to wrong URL, or trying to
	 * access the invalid web page, it will redirect to the "Error" page.
	 * 
	 * @return String it will redirect to Error page
	 */
	@RequestMapping("Error")
	public String error() {
		return "Error";
	}

}
