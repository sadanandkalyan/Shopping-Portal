package shopping.gogreen.controller;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.ContactUs;
import shopping.gogreen.domain.Order;
import shopping.gogreen.domain.Products;
import shopping.gogreen.domain.User;
import shopping.gogreen.services.CartService;
import shopping.gogreen.services.OrderService;
import shopping.gogreen.services.ProductService;
import shopping.gogreen.services.UserService;

/**
 * UserController.java : It controls the redirections from the Users Page to
 * another JSP page and do the appropriate functions based on the
 * RequestMapping.
 */
@Controller
public class UserController {

	/**
	 * These objects will be initialized by the spring container.
	 */
	@Autowired
	UserService userService;

	@Autowired
	CartService cartService;

	@Autowired
	OrderService orderService;

	@Autowired
	ProductService productService;

	@Autowired
	WebApplicationContext context;

	/**
	 * It will redirect to the login page.The attributes are set to true, for
	 * notifying the user in the JSP "Login" page.
	 * 
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @param session
	 *            To set and get the attributes.
	 * @return login It will redirect to that JSP page.
	 */
	@RequestMapping("/login")
	public String loginPage(HttpSession session, Model model) {

		if (session.getAttribute("checkLoginForCart") != null) {
			model.addAttribute("checkLoginForCart", true);
			session.removeAttribute("checkLoginForCart");
		}
		if (session.getAttribute("checkErrorLogin") != null) {
			model.addAttribute("checkErrorLogin", true);
			session.removeAttribute("checkErrorLogin");
		}
		if (session.getAttribute("checkSignUp") != null) {
			model.addAttribute("checkSignUp", true);
			session.removeAttribute("checkSignUp");
		}
		if (session.getAttribute("passwordUpdated") != null) {
			model.addAttribute("passwordUpdated", true);
			session.removeAttribute("passwordUpdated");
		}
		if (session.getAttribute("forgotDetailsWrong") != null) {
			model.addAttribute("forgotDetailsWrong", true);
			session.removeAttribute("forgotDetailsWrong");
		}
		if (session.getAttribute("duplicateEntry") != null) {
			model.addAttribute("duplicateEntry", true);
			session.removeAttribute("duplicateEntry");
		}
		// If the logout is successful, then the session is invalidated.
		if (session.getAttribute("logoutSuccess") != null) {
			model.addAttribute("logoutSuccess", true);
			session.removeAttribute("logoutSuccess");
			session.invalidate();
		}

		return "Login";
	}

	/**
	 * After the Customer has logout, it will redirect to login page.
	 * 
	 * @param session
	 *            To set and get the attributes.
	 * @return String it will redirect to login page.
	 */
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.setAttribute("logoutSuccess", true);
		return "redirect:/login";
	}

	/**
	 * For registering the Customer details into the database.The email and
	 * mobile are Unique for each customer. Hence Duplicate entries are checked
	 * with this email and mobile number. If duplicate entries are found, then
	 * it will give error notification. If not, the password is hashed with the
	 * "SHA_512_SecurePassword" method and salt "SHA1PRNG". The security answer
	 * is also Hashed with same salt.This salt is unique for each customer. The
	 * details are inserted into the database.
	 * 
	 * @param session
	 *            To set and get the attributes.
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @return String it will redirect to login page.
	 */
	@RequestMapping("/signUpPage")
	public String signUpPage(HttpServletRequest request, HttpSession session) {

		String email = request.getParameter("email");
		long contactNumber = Long.parseLong(request.getParameter("contactNumber"));
		boolean check = userService.checkDuplicateEntries(email, contactNumber);
		if (check) {
			session.setAttribute("duplicateEntry", "true");
			return "redirect:/login";
		}

		String password = request.getParameter("password");
		byte[] salt = getSalt();
		password = get_SHA_512_SecurePassword(password, salt);

		String securityAnswer = request.getParameter("securityAnswer");
		securityAnswer = get_SHA_512_SecurePassword(securityAnswer, salt);

		User user = getUser();
		user.setEmail(request.getParameter("email"));
		user.setPassword(password);
		user.setMobile(Long.parseLong(request.getParameter("contactNumber")));
		user.setCustomerName(request.getParameter("customerName"));
		user.setSecurityAnswer(securityAnswer);
		user.setSalt(salt);

		userService.insertData(user);
		session.setAttribute("checkSignUp", true);
		return "redirect:/login";
	}

	/**
	 * To check the User login details, entered are correct or not.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("/loginCheck")
	public String verifyLogin(HttpServletRequest request, HttpSession session) {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		byte[] salt;
		salt = userService.getSalt(email);
		if (salt != null) {
			password = get_SHA_512_SecurePassword(password, salt);
			String name = userService.getUser(email, password);
			if (name != null) {
				session.setAttribute("uname", name);
				session.setAttribute("email", email);
				session.setAttribute("loginSuccess", true);
				return "redirect:/";
			} else {
				session.setAttribute("checkErrorLogin", true);
				return "redirect:/login";
			}

		} else {
			session.setAttribute("checkErrorLogin", true);
			return "redirect:/login";
		}
	}

	/**
	 * If customer forgot the password, then he can change the password using
	 * the email and Security answer.The security answer is hashed before saving
	 * into the database. Hence to check the security answer, we need to again
	 * hash the security answer, and then comparison is done. The salt is also
	 * stored in the database, Hence we will also retrieve salt from the
	 * database, using the email. If the details are correct, it will redirect
	 * to the "ForgotPassword" page. else, it will redirect to the login page,
	 * showing the notification, that the entered details are wrong.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @return String It will redirect to that JSP page
	 */
	@PostMapping("/forgotPassword")
	public String forgotPassword(HttpServletRequest request, HttpSession session, Model model) {
		String email = request.getParameter("email");
		String securityAnswer = request.getParameter("securityAnswer");

		byte[] salt;

		salt = userService.getSalt(email);
		if (salt == null) {
			session.setAttribute("forgotDetailsWrong", true);
			return "redirect:/login";
		}
		securityAnswer = get_SHA_512_SecurePassword(securityAnswer, salt);

		String password = userService.forgotPassword(email, securityAnswer);
		if (password != null) {
			model.addAttribute("email", email);
			return "ForgotPassword";
		} else {
			session.setAttribute("forgotDetailsWrong", true);
			return "redirect:/login";
		}
	}

	/**
	 * If the customer forgot the password and wants to update new password, he
	 * need to provide the email and security answer. The details are passed
	 * from the JSP page to this controller. First it will checks the passwords,
	 * both are equal or not, then the salt is Retrieved from the Database. The
	 * password is hashed and updated in the database with email.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("/changePassword")
	public String changePassword(HttpServletRequest request, HttpSession session) {
		String password = request.getParameter("password");
		String confirmPassword = request.getParameter("confirmPassword");
		if (password.equals(confirmPassword)) {
			String email = (String) request.getParameter("email");
			byte[] salt = userService.getSalt(email);
			password = get_SHA_512_SecurePassword(password, salt);
			userService.setNewPassword(password, email);
			session.setAttribute("passwordUpdated", true);
			return "redirect:/login";
		} else {
			session.setAttribute("passwordMismatch", true);
			return "redirect:/getForgotPassword";
		}
	}

	/**
	 * This is the AccountInfo controller. The user details are retrieved from
	 * the database, and displayed in the JSP page. The attributes are added to
	 * the model, for the notifications to be displayed on the JSP page.
	 * 
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("accountInfo")
	public String accountInfo(HttpSession session, Model model) {

		User user = userService.getUserDetails((String) session.getAttribute("email"));
		model.addAttribute("userDetails", user);

		if (session.getAttribute("passwordChanged") != null) {
			model.addAttribute("passwordChanged", true);
			session.removeAttribute("passwordChanged");
		}
		if (session.getAttribute("passwordMismatch") != null) {
			model.addAttribute("passwordMismatch", true);
			session.removeAttribute("passwordMismatch");
		}
		if (session.getAttribute("updatedContactNumber") != null) {
			model.addAttribute("updatedContactNumber", true);
			session.removeAttribute("updatedContactNumber");
		}

		// Cart Size is added to the model, for displaying the cart count in the
		// Header JSp Page.
		int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
		model.addAttribute("cartSize", cartSize);
		return "AccountInfo";
	}

	/**
	 * If the customer wants to update the password, then he can update it with
	 * the old password using this option. For this, the user needs to enter the
	 * old password along with the new password. The parameters are passed from
	 * the JSP page to this controller. The old password is checked with the
	 * password in database(after doing Hashing), If it is correct, then it will
	 * update the new password after hashing in the database. Else, notification
	 * is shown telling that the entered password doesn't match with the
	 * database.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("/updatePassword")
	public String updatePassword(HttpServletRequest request, HttpSession session) {
		String enteredPassword = request.getParameter("oldPassword");
		String email = (String) session.getAttribute("email");
		byte[] salt = userService.getSalt(email);
		enteredPassword = get_SHA_512_SecurePassword(enteredPassword, salt);
		String password = userService.getPassword(email);

		if (enteredPassword.equals(password)) {
			String newPassword = request.getParameter("newPassword");
			String confirmPassword = request.getParameter("confirmNewPassword");
			if (newPassword.equals(confirmPassword)) {
				newPassword = get_SHA_512_SecurePassword(newPassword, salt);
				userService.setNewPassword(newPassword, email);
				session.setAttribute("passwordChanged", true);
				return "redirect:/accountInfo";
			} else {
				session.setAttribute("passwordMismatch", true);
				return "redirect:/accountInfo";
			}
		} else {
			session.setAttribute("passwordMismatch", true);
			return "redirect:/accountInfo";
		}
	}

	/**
	 * The customer can change his mobile number, provided with the email.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("/updateInfo")
	public String updateInfo(HttpServletRequest request, HttpSession session) {
		String email = (String) session.getAttribute("email");
		long mobile = Long.parseLong(request.getParameter("contactNumber"));
		userService.updateMobile(email, mobile);
		session.setAttribute("updatedContactNumber", true);
		return "redirect:/accountInfo";
	}

	/**
	 * The customer can complaint regarding the orders, delivery process, etc.
	 * we will take the following details from the "Contact Us" page. Email,
	 * contactNumber, customerName, and complaint. These details are stored in
	 * the database.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("/contactPage")
	public String contactPage(HttpServletRequest request, HttpSession session) {

		ContactUs contactUs = getContactUs();
		contactUs.setCustomerName(request.getParameter("customerName"));
		contactUs.setEmail(request.getParameter("email"));
		contactUs.setMobile(Long.parseLong(request.getParameter("contactNumber")));
		contactUs.setDescription(request.getParameter("description"));
		userService.insertComplaints(contactUs);
		session.setAttribute("submitContactForm", true);
		return "redirect:/";
	}

	/**
	 * The customer can check the order details.The total order List is
	 * retrieved from the database and from this orders, we will get the product
	 * details, in the form of list. These two lists are added to the model,
	 * which will be accessed in the JSP page.
	 * 
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("/order")
	public String orderDetails(HttpSession session, Model model) {
		String email = (String) session.getAttribute("email");
		List<Order> orderList = orderService.getOrderDetails(email);
		List<Products> productsList = getProductList();
		productsList.clear();
		Products products;
		for (Order order : orderList) {
			int productID = order.getProductID();
			products = productService.getSingleProductDetails(productID);
			productsList.add(products);
		}
		model.addAttribute("orderList", orderList);
		model.addAttribute("productsList", productsList);
		int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
		model.addAttribute("cartSize", cartSize);
		Date date = userService.getServerDate();
		model.addAttribute("todayDate", date);
		return "OrderDetails";
	}

	/**
	 * This method hash the password entered by the user using the SHA_512
	 * algorithm. It is better than MD5.
	 * 
	 * @param passwordToHash
	 *            password entered by the user
	 * @param salt
	 *            unique salt generated for each user.
	 * @return String Hashed password
	 */
	private String get_SHA_512_SecurePassword(String passwordToHash, byte[] salt) {
		String generatedPassword = null;
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			md.update(salt);
			byte[] bytes = md.digest(passwordToHash.getBytes());
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < bytes.length; i++) {
				sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
			}
			generatedPassword = sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return generatedPassword;
	}

	/**
	 * Salt is generated for each user and stored in the database.
	 * 
	 * @return Byte Array the generated salt.
	 */
	private byte[] getSalt() {
		SecureRandom sr;
		try {
			sr = SecureRandom.getInstance("SHA1PRNG");
			byte[] salt = new byte[16];
			sr.nextBytes(salt);
			return salt;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
	}

	public User getUser() {
		return (User) context.getBean("userRq");
	}

	public ContactUs getContactUs() {
		return (ContactUs) context.getBean("contactUs");
	}

	@SuppressWarnings("unchecked")
	public List<Products> getProductList() {
		return (List<Products>) context.getBean("productList");
	}

}
