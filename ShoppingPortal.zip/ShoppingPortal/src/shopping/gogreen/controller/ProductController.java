package shopping.gogreen.controller;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import shopping.gogreen.dao.ProductDao;
import shopping.gogreen.domain.Products;
import shopping.gogreen.services.CartService;
import shopping.gogreen.services.ProductService;

/**
 * ProductController.java : It controls the redirections from the Products Page
 * to another JSP page and do the appropriate functions based on the
 * RequestMapping.
 */
@Controller
public class ProductController {

	@Autowired
	ProductService productService;

	@Autowired
	ProductDao productDao;

	@Autowired
	CartService cartService;

	/**
	 * To get the Total productsList and we will add this list to the model.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 */
	@RequestMapping("/categoryPage")
	public String showCategoryPage(Model model, HttpServletRequest request, HttpSession session) {

		String name = request.getParameter("cat");
		List<Products> productList = productService.getCategoryList(name);
		if (productList.isEmpty()) {
			model.addAttribute("productsList", null);
			return "ErrorPage404";
		} else {
			name = name.toUpperCase();
			model.addAttribute("category", name);
			model.addAttribute("productList", productList);
		}
		int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
		model.addAttribute("cartSize", cartSize);
		return "Category";
	}

	/**
	 * To get the singleProductDetails and corresponding category for displaying
	 * the particular product details in the Shopping.jsp page.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 */

	@RequestMapping("/Shopping")
	public String getProduct(HttpServletRequest request, Model model, HttpSession session) {
		try {
			int productID = Integer.parseInt(request.getParameter("product"));
			Products productList = productService.getSingleProductDetails(productID);
			String category = productList.getCategory();
			List<Products> categoryList = productService.getCategoryList(category);
			model.addAttribute("categoryList", categoryList);
			model.addAttribute("productList", productList);
			int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
			model.addAttribute("cartSize", cartSize);
			return "Shopping";
		} catch (Exception e) {
			System.out.println(e);
			return "Error";
		}

	}

	/**
	 * If the customer search for a particular product, it will execute this
	 * method. Based on the search, it will get all products, when the "search"
	 * name is present in the ProductName.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 */
	@RequestMapping("/search")
	public String search(HttpServletRequest request, Model model, HttpSession session) {
		String search = request.getParameter("search");
		List<Products> productList = productService.search(search);
		// if the product list is empty, it is set to null.
		if (productList.isEmpty()) {
			model.addAttribute("productList", null);
		} else {
			model.addAttribute("search", search);
			model.addAttribute("productList", productList);
		}
		int cartSize = cartService.getCartCount((String) session.getAttribute("email"));
		model.addAttribute("cartSize", cartSize);
		return "Search";
	}

	/**
	 * 
	 * @param productID
	 * @param response
	 * @param request
	 * @throws ServletException
	 * @throws IOException
	 * @throws SQLException
	 */
	@RequestMapping(value = "/imageDisplay")
	public void showImage(@RequestParam("id") Integer productID, HttpServletResponse response,
			HttpServletRequest request) throws ServletException, IOException, SQLException {
		Blob blob = productDao.getImage(productID);
		byte[] imgByte = null;
		imgByte = blob.getBytes(1, (int) blob.length());
		response.setContentType("image/jpeg");
		response.getOutputStream().write(imgByte);
		response.getOutputStream().close();

	}
}
