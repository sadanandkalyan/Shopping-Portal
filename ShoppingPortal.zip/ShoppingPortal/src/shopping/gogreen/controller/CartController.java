package shopping.gogreen.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import shopping.gogreen.domain.Cart;
import shopping.gogreen.domain.Products;
import shopping.gogreen.services.CartService;
import shopping.gogreen.services.OrderService;
import shopping.gogreen.services.ProductService;

/**
 * CartController.java : It controls the redirections from the cart Page to
 * another JSP page and do the appropriate functions based on the
 * RequestMapping.
 */
@Controller
public class CartController {

	@Autowired
	ProductService productService;

	@Autowired
	OrderService orderService;

	@Autowired
	CartService cartService;

	@Autowired
	WebApplicationContext context;

	/**
	 * It will show all the products in the cart page, that the customer has
	 * added the products to the cart, using the option "Add to Cart". Without
	 * login, the customer cannot open the cart page.
	 * 
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @return String It will redirect to that JSP page
	 */

	@RequestMapping("/cart")
	public String cart(HttpSession session, Model model) {
		if (session.getAttribute("uname") != null) {
			List<Cart> cartlist;
			Products product;
			// this variable will be set true if product from the cart got
			// removed because of out of stock.
			boolean removed = false;
			List<Products> productList = getProductList();
			productList.clear();
			String email = (String) session.getAttribute("email");
			cartlist = cartService.getCart(email);
			for (int i = 0; i < cartlist.size(); i++) {
				if (cartlist.get(i).getPayment() != 0) {
					// if product is in stock adding to ProductDetailList
					product = productService.getSingleProductDetails(cartlist.get(i).getProductID());
					productList.add(product);
				} else {
					// if some product in cart becomes out of stock setting
					// removes to true
					removed = true;
				}
			}

			if (removed) {
				// removing the products from the cart which got out of stock.
				cartService.removeCartWithEmail(email);
			}
			// adding ProductDetailList to model for viewing.
			model.addAttribute("productsList", productList);
			// adding cartsize to the model
			model.addAttribute("cartSize", cartService.getCartCount(email));
			// for notifying user about some products got removed because of out
			// of stock.
			model.addAttribute("removed", removed);
			// if user press checkout with empty cart.
			model.addAttribute("cartEmpty", session.getAttribute("cartEmpty"));
			// removing the session attribute after it's use.
			session.removeAttribute("cartEmpty");
			// if user press remove product in cart page then for notifying user
			// this variable is used
			model.addAttribute("removedFromCart", session.getAttribute("removedFromCart"));
			session.removeAttribute("removedFromCart");

			return "Cart";
		} else
			// notifying user to login for viewing cart
			session.setAttribute("checkLoginForCart", true);

		return "redirect:/login";
	}

	/**
	 * The customer can add the products to the cart.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@PostMapping("/addtocart")
	public String addToCart(HttpServletRequest request, HttpSession session) {
		// if user is logged in.
		if ((session.getAttribute("uname") != null) && (session.getAttribute("email") != null)) {
			int productID = Integer.parseInt(request.getParameter("productID"));
			String email = (String) session.getAttribute("email");

			int orderID = orderService.getOrderID(productID, email);
			// if user already purchased the product then notifying him.
			if ((orderID) != 0) {

				return "ReOrder";
			}

			List<Cart> cartList = cartService.getCart(email);
			for (int i = 0; i < cartList.size(); i++) {
				if (cartList.get(i).getProductID() == (productID)) {
					// if user tries to add same product twice then notifying
					// him.
					session.setAttribute("sameProduct", true);
					return "redirect:/";
				}
			}
			// on successful addition of product to the cart.
			cartService.addToCart(productID, email);
			session.setAttribute("addedToCart", true);
			return "redirect:/";

		} else {
			// notifying user to login.
			session.setAttribute("checkLoginForCart", true);
			return "redirect:/login";
		}
	}

	/**
	 * customer can remove the products from the cart page with the productID.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @return String It will redirect to that JSP page
	 */
	@RequestMapping("/remove")
	public String remove(HttpServletRequest request, HttpSession session) {
		// getting productid that has to be removed from the cart
		int productID = Integer.parseInt(request.getParameter("productID"));
		// removing from the cart and notifying him.
		cartService.removeCart(productID);
		session.setAttribute("removedFromCart", true);
		return "redirect:/cart";
	}

	/**
	 * If the customer clicks the buy now or check out option, it will first
	 * check whether he has logged in or not. Based on that it will redirect to
	 * the different pages.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param session
	 *            To set and get the attributes.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @return String It will redirect to that JSP page
	 */

	@PostMapping("/buynow")
	public String buynow(HttpSession session, Model model, HttpServletRequest request) {

		String buy = request.getParameter("productID");
		// if user press buy now this block is executed
		if ((session.getAttribute("uname") != null) && (session.getAttribute("email") != null)
				&& (request.getParameter("cart") == null) && (request.getParameter("productID") != null)) {
			int orderID = orderService.getOrderID(Integer.parseInt(buy), (String) session.getAttribute("email"));
			// if user already purchased the product then notifying him.
			if ((orderID) != 0) {
				return "ReOrder";
			}
			// adding the product id to the model
			model.addAttribute("productID", buy);
			return "Shipping";

		} // if user press check out this block gets executed
		else if ((session.getAttribute("uname") != null) && (session.getAttribute("email") != null)
				&& (request.getParameter("cart") != null) && (request.getParameter("productID")) == null) {

			if (cartService.getCartCount((String) session.getAttribute("email")) > 0) {
				model.addAttribute("cart", request.getParameter("cart"));
				return "Shipping";

			} else {
				// if user press check out with empty cart then notifying him
				session.setAttribute("checkOutIfEmpty", true);
				return "redirect:/";
			}
		} else {
			// notifying user to login.
			session.setAttribute("checkLoginForCart", true);
			return "redirect:/login";
		}
	}

	/**
	 * The shipping address is taken from the JSP page and is concatenated into
	 * one string. Based on the option - Buy Now or check out, it will redirect
	 * to Payment page.
	 * 
	 * @param request
	 *            To get the parameters, entered in the browser.
	 * @param model
	 *            To set the attributes to the model for showing the
	 *            notifications in the JSP page.
	 * @return String It will redirect to that JSP page
	 */
	@PostMapping("/shipping")
	public String shipping(HttpServletRequest request, Model model) {
		String ship = request.getParameter("shippingAddress") + "," + request.getParameter("street") + ","
				+ request.getParameter("town") + "," + request.getParameter("state") + ","
				+ request.getParameter("pincode");
		if (request.getParameter("cart").equals("") && !request.getParameter("productID").equals(null)) {
			// this attribute is to notify that user is paying by pressing buy
			// now option
			model.addAttribute("productID", request.getParameter("productID"));
			model.addAttribute("ship", ship);
			return "Payment";
		}
		if (request.getParameter("productID").equals("") && request.getParameter("cart").equals("cart")) {
			// this attribute is to notify that user is paying by pressing
			// checkout option not buy now
			model.addAttribute("cart", request.getParameter("cart"));
			model.addAttribute("ship", ship);
			return "Payment";
		}
		return "fail";
	}

	@SuppressWarnings("unchecked")
	public List<Products> getProductList() {
		return (List<Products>) context.getBean("productList");
	}
}
