package shopping.gogreen.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Order;
import shopping.gogreen.jdbc.OrderRowMapper;

/**
 * OrderDaoImpl.java : In this class, the methods of OrderDao interface are
 * implemented.
 */

public class OrderDaoImpl implements OrderDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	WebApplicationContext context;

	/**
	 * Insert the order details in to the database provided the Order object.
	 * 
	 * @param order
	 *            Order Object to get the data of Instance variables of Order
	 *            class.
	 */
	@Override
	public void insertOrder(Order order) {

		try {
			String sql = "INSERT INTO orderTable(email,productID,bookingDate,"
					+ "amountpaid,shippingAddress,deliveryDate) VALUES (?,?,?,?,?,?)";

			jdbcTemplate.update(sql, new Object[] { order.getEmail(), order.getProductID(), order.getDateOfBooking(),
					order.getAmountPaid(), order.getShippingAddress(), order.getDeliveryDate() });
		} catch (Exception e) {
			System.out.println(e.getMessage());

		}
	}

	/**
	 * To get the OrderID from the database provided the ProductID and email
	 * 
	 * @param productID
	 *            Unique for each product.
	 * @param email
	 *            unique for each customer.
	 * @return int the OrderID for that productID and email.
	 */
	@Override
	public int getOrderID(int productID, String email) {
		String sql = "select orderID from orderTable where productID=  ? and email = ? ";

		try {

			int q = (int) jdbcTemplate.queryForObject(sql, new Object[] { productID, email }, int.class);

			return q;
		} catch (IncorrectResultSizeDataAccessException e) {

			return 0;
		}
	}

	/**
	 * Get the orderDetails from the database provided the email.
	 * 
	 * @param email
	 *            unique for each customer.
	 * @return List of Order objects with the order details of that User.
	 */
	@Override
	public List<Order> getOrderDetails(String email) {

		try {
			List<Order> orderList = getOrderList();
			String sql = "select * from orderTable where email = ? ";

			orderList = jdbcTemplate.query(sql, new Object[] { email }, getOrderRowMapper());
			return orderList;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	public OrderRowMapper getOrderRowMapper() {
		return (OrderRowMapper) context.getBean("orderRowMapper");
	}

	@SuppressWarnings("unchecked")
	public List<Order> getOrderList() {
		return (List<Order>) context.getBean("orderList");
	}
}
