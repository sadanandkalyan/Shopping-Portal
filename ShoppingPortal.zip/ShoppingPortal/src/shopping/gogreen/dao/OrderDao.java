package shopping.gogreen.dao;

import java.util.List;

import shopping.gogreen.domain.Order;

/**
 * OrderDao.java : This interface has to be implemented for providing the
 * services mentioned in the OrderService for the user.
 */
public interface OrderDao {

	/**
	 * Insert the order details in to the database provided the Order object.
	 * 
	 * @param order
	 *            Order Object to get the data of Instance variables of Order
	 *            class.
	 */
	public void insertOrder(Order order);

	/**
	 * To get the OrderID from the database provided the ProductID and email
	 * 
	 * @param productID
	 *            Unique for each product.
	 * @param email
	 *            unique for each customer.
	 * @return int the OrderID for that productID and email.
	 */
	public int getOrderID(int productID, String email);

	/**
	 * Get the orderDetails from the database provided the email.
	 * 
	 * @param email
	 *            unique for each customer.
	 * @return List of Order objects with the order details of that User.
	 */
	public List<Order> getOrderDetails(String email);

}
