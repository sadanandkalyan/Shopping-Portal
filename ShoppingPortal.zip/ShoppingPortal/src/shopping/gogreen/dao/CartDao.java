package shopping.gogreen.dao;

import java.util.List;
import shopping.gogreen.domain.Cart;

/**
 * CartDao.java : This interface has to be implemented for providing the
 * services mentioned in the cartService for the user.
 */
public interface CartDao {

	/**
	 * Get the cart size from the database to the Cart page.
	 * 
	 * @param email
	 * @return int the number of products present in the cart table for that
	 *         user(email)
	 */
	public int getCartCount(String email);

	/**
	 * Removes the product from the cart, provided with the productID.
	 * 
	 * @param productID
	 *            unique for each product.
	 */
	public void removeCart(int productID);

	/**
	 * Get the total product present in the Cart table for that user(email).
	 * 
	 * @param email
	 *            unique for each customer
	 * @return List of cart Objects of that user.
	 */
	public List<Cart> getCart(String email);

	/**
	 * Remove the product from the cart for that particular user(email)
	 * 
	 * @param email
	 *            unique for each customer
	 */
	public void removeCartWithEmail(String email);

	/**
	 * The products are added to the cart.
	 * 
	 * @param productID
	 *            unique for each product
	 * @param email
	 *            unique for each customer.
	 */
	public void addToCart(int productID, String email);

}
