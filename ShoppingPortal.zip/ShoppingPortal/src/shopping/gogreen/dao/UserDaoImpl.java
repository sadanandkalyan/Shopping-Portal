package shopping.gogreen.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.context.WebApplicationContext;

import java.sql.Blob;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import shopping.gogreen.domain.ContactUs;
import shopping.gogreen.domain.User;
import shopping.gogreen.jdbc.UserRowMapper;

/**
 * UserDaoImpl.java : In this class, the methods of UserDao interface are
 * implemented.
 */

public class UserDaoImpl implements UserDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	WebApplicationContext context;

	/**
	 * User data entered from the form (taken through browser), is inserted into
	 * the database.
	 * 
	 * @param User
	 *            object from the which the Instance variables data is
	 *            retrieved.
	 */
	@Override
	public void insertData(User user) {

		try {
			String sql = "INSERT INTO customertable "
					+ "(email,password,mobile,customerName,secAns,salt) VALUES (?,?,?,?,?,?)";

			jdbcTemplate.update(sql, new Object[] { user.getEmail(), user.getPassword(), user.getMobile(),
					user.getCustomerName(), user.getSecurityAnswer(), user.getSalt() });
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	/**
	 * To get the User name from the email and password.
	 * 
	 * @param email
	 *            unique for each customer.
	 * @param password
	 *            given by the user while signUp.
	 * @return String User name from the email and password
	 */
	@Override
	public String getUser(String email, String password) {

		String sql = "select customerName from customertable where email=  ? and password = ? ";

		try {
			String name = jdbcTemplate.queryForObject(sql, new Object[] { email, password }, String.class);
			return name;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	/**
	 * To get the User details from the email in the form of User Object.
	 * 
	 * @param email
	 *            unique for each customer
	 * @return User Object with the data details from the database.
	 */
	@Override
	public User getUserDetails(String email) {
		String sql = "select * from customerTable where email = ?";
		List<User> userDetails = jdbcTemplate.query(sql, new Object[] { email }, getUserRowMapper());
		return userDetails.get(0);
	}

	/**
	 * For checking the duplicate entries, while registering the user details.
	 * 
	 * @param email
	 *            unique for each customer
	 * @param mobile
	 *            unique for each customer
	 * @return boolean {@code true} if duplicate entries are found.
	 *         {@code false} if not found.
	 */
	@Override
	public boolean checkDuplicateEntries(String email, Long mobile) {

		String sql = "select password from customertable where email =  ?";
		String sql1 = "select password from customertable where mobile =  ?";
		String password = null;
		String password1 = null;

		try {
			System.out.println("check " + email + mobile);
			password = jdbcTemplate.queryForObject(sql, new Object[] { email }, String.class);
		} catch (EmptyResultDataAccessException e) {
			password = null;
		}

		try {
			password1 = jdbcTemplate.queryForObject(sql1, new Object[] { mobile }, String.class);
		} catch (EmptyResultDataAccessException e) {
			password1 = null;
			// e.printStackTrace();
		}
		System.out.println(password + password1);
		if (password != null || password1 != null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * For getting the old password from the database, based on the email and
	 * security answer.
	 * 
	 * @param email
	 *            unique for each customer
	 * @param securityAnswer
	 *            provided by the user for creating new password.
	 * @return String the old password.
	 */
	@Override
	public String forgotPassword(String email, String securityAnswer) {
		String sql = "select password from customerTable where email=  ? and secAns = ?";

		try {
			String oldPassword = (String) jdbcTemplate.queryForObject(sql, new Object[] { email, securityAnswer },
					String.class);
			return oldPassword;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	/**
	 * The user can set the new password provided the old password and email.
	 * 
	 * @param password
	 *            old password should be provided by the user
	 * @param email
	 *            unique for each customer
	 */
	@Override
	public void setNewPassword(String password, String email) {

		String sql = "UPDATE customerTable set password = ? where email = ? ";
		jdbcTemplate.update(sql, new Object[] { password, email });
	}

	/**
	 * To get the password provided the email
	 * 
	 * @param email
	 *            unique for each customer
	 * @return String the password present in the database.
	 */
	@Override
	public String getPassword(String email) {
		String sql = "select password from customerTable where email = ? ";

		try {
			String oldPassword = (String) jdbcTemplate.queryForObject(sql, new Object[] { email }, String.class);
			return oldPassword;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	/**
	 * To update the mobile number in the database.
	 * 
	 * @param email
	 *            unique for each customer
	 * @param mobile
	 *            unique for each customer
	 */
	@Override
	public void updateMobile(String email, long mobile) {

		String sql = "UPDATE customerTable set mobile = ? where email = ?";

		jdbcTemplate.update(sql, new Object[] { mobile, email });

	}

	/**
	 * The complaints are inserted in to the database, provided with the
	 * ContactUs object.
	 * 
	 * @param contactUs
	 *            Object with the details
	 */
	@Override
	public void insertComplaints(ContactUs contactUs) {
		String sql = "INSERT INTO complaintsTable " + "(email,customerName,mobile,complaint) VALUES (?,?,?,?)";

		jdbcTemplate.update(sql, new Object[] { contactUs.getEmail(), contactUs.getCustomerName(),
				contactUs.getMobile(), contactUs.getDescription() });
	}

	/**
	 * For hashing the password, this salt is required. Salt is retrieved from
	 * the database.
	 * 
	 * @param email
	 *            unique for each customer
	 * @return byte array
	 */
	@Override
	public byte[] getSalt(String email) {
		String sql = "select salt from customerTable where email= ? ";
		Blob salt;
		try {
			salt = (Blob) jdbcTemplate.queryForObject(sql, new Object[] { email }, Blob.class);
			int blobLength = (int) salt.length();

			byte[] blobAsBytes = salt.getBytes(1, blobLength);

			return blobAsBytes;
		} catch (EmptyResultDataAccessException | SQLException e) {
			return null;
		}
	}

	/**
	 * To get the current Date from the server.
	 * 
	 * @return Date current date
	 */
	public Date getServerDate() {
		String sql = "select curdate() ";
		Date date = (Date) jdbcTemplate.queryForObject(sql, Date.class);
		return date;
	}

	public UserRowMapper getUserRowMapper() {
		return (UserRowMapper) context.getBean("userRowMapper");
	}

}
