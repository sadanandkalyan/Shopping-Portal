package shopping.gogreen.dao;

import java.sql.Date;

import shopping.gogreen.domain.ContactUs;
import shopping.gogreen.domain.User;

/**
 * UserDao.java : This interface has to be implemented for providing the
 * services mentioned in the UserService for the user.
 */
public interface UserDao {

	/**
	 * method for inserting the data into the User object
	 * 
	 * @param user
	 *            Object is returned after the data is inserted into the Object.
	 */
	public void insertData(User user);

	/**
	 * To get the User name from the email and password.
	 * 
	 * @param email
	 *            unique for each customer.
	 * @param password
	 *            given by the user while signUp.
	 * @return String User name from the email and password
	 */
	public String getUser(String email, String password);

	/**
	 * For checking the duplicate entries, while registering the user details.
	 * 
	 * @param email
	 *            unique for each customer
	 * @param mobile
	 *            unique for each customer
	 * @return boolean {@code true} if duplicate entries are found.
	 *         {@code false} if not found.
	 */
	public boolean checkDuplicateEntries(String email, Long mobile);

	/**
	 * For getting the old password from the database, based on the email and
	 * security answer.
	 * 
	 * @param email
	 *            unique for each customer
	 * @param securityAnswer
	 *            provided by the user for creating new password.
	 * @return String the old password.
	 */
	public String forgotPassword(String email, String securityAnswer);

	/**
	 * The user can set the new password provided the old password and email.
	 * 
	 * @param password
	 *            old password should be provided by the user
	 * @param email
	 *            unique for each customer
	 */
	public void setNewPassword(String password, String email);

	/**
	 * To get the User details from the email in the form of User Object.
	 * 
	 * @param email
	 *            unique for each customer
	 * @return User Object with the data details from the database.
	 */
	public User getUserDetails(String email);

	/**
	 * To get the password provided the email
	 * 
	 * @param email
	 *            unique for each customer
	 * @return String the password present in the database.
	 */
	public String getPassword(String email);

	/**
	 * To update the mobile number in the database.
	 * 
	 * @param email
	 *            unique for each customer
	 * @param mobile
	 *            unique for each customer
	 */
	public void updateMobile(String email, long mobile);

	/**
	 * The complaints are inserted in to the database, provided with the
	 * ContactUs object.
	 * 
	 * @param contactUs
	 *            Object with the details
	 */
	public void insertComplaints(ContactUs contactUs);

	/**
	 * For hashing the password, this salt is required. Salt is retrieved from
	 * the database.
	 * 
	 * @param email
	 *            unique for each customer
	 * @return byte array
	 */
	public byte[] getSalt(String email);

	/**
	 * To get the current Date from the server.
	 * 
	 * @return Date current date
	 */
	public Date getServerDate();

}
