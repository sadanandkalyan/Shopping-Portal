package shopping.gogreen.dao;

import java.sql.Blob;
import java.util.List;

import shopping.gogreen.domain.Products;

/**
 * ProductDao.java : This interface has to be implemented for providing the
 * services mentioned in the ProductService for the user.
 */
public interface ProductDao {

	/**
	 * Get the total productsList from the database.
	 * 
	 * @return List of products
	 */
	public List<Products> getProductsList();

	/**
	 * Get the single productDetails provided the ProductID
	 * 
	 * @param productID
	 *            Unique for each product.
	 * @return Product Object that contain the details of the product.
	 */
	public Products getSingleProductDetails(int productID);

	/**
	 * Get the total products present in that category.
	 * 
	 * @param category
	 *            get all product of that category.
	 * @return List of products.
	 */
	public List<Products> getCategoryList(String category);

	/**
	 * To get the Image from the database, provided the productID
	 * 
	 * @param productID
	 *            unique for each product
	 * @return Blob product image from the database.
	 */
	public Blob getImage(int productID);

	/**
	 * returns the List of productID's of all the products.
	 * 
	 * @return List of ProductID's
	 */
	public List<Integer> getProductsId();

	/**
	 * search for the String provided as the parameter, in the database
	 * 
	 * @param search
	 *            the text that the user is searching for.
	 * @return List of products having product name that matches with the text.
	 */
	public List<Products> search(String search);

	/**
	 * Get the count of total number of products present in the database.
	 * 
	 * @param productID
	 *            unique for each product
	 * @return int the total number of products present in the database for that
	 *         product.
	 */
	public int getQuantity(int productID);

	/**
	 * Decrease the quantity of the product by one, provided the product ID.
	 * 
	 * @param productID
	 *            unique for each product
	 * @return {@code true} if quantity i decreased. {@code false} if not.
	 */
	public boolean decreaseQuantity(int productID);

	/**
	 * It will increase the quantity of the Product provided the productID.
	 * 
	 * @param productID
	 *            unique for each product
	 */
	public void increaseQuantity(int productID);

}
