package shopping.gogreen.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Cart;
import shopping.gogreen.jdbc.CartRowMapper;

/**
 * CartDaoImpl.java : In this class, the methods of CartDao interface are
 * implemented.
 */

public class CartDaoImpl implements CartDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	WebApplicationContext context;

	/**
	 * The products are added to the cart.
	 * 
	 * @param productID
	 *            unique for each product
	 * @param email
	 *            unique for each customer.
	 */
	@Override
	public void addToCart(int productID, String email) {
		try {
			String sql = "INSERT INTO cartTable(email,productID,payment) VALUES (?,?,?)";
			boolean payment = true;

			jdbcTemplate.update(sql, new Object[] { email, productID, payment });
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Get the cart size from the database to the Cart page.
	 * 
	 * @param email
	 * @return int the number of products present in the cart table for that
	 *         user(email)
	 */
	@Override
	public int getCartCount(String email) {
		try {
			String sql = "select count(*) from cartTable where email = ? ";

			int list = jdbcTemplate.queryForObject(sql, new Object[] { email }, Integer.class);

			return list;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return 0;
		}
	}

	/**
	 * Get the total product present in the Cart table for that user(email).
	 * 
	 * @param email
	 *            unique for each customer
	 * @return List of cart Objects of that user.
	 */

	@Override
	public List<Cart> getCart(String email) {
		String sql = "select productID, payment from carttable where email = ? ";
		System.out.println(email);
		List<Cart> pid = getCartList();

		pid = jdbcTemplate.query(sql, new Object[] { email }, getCartRowMapper());
		return pid;
	}

	/**
	 * Removes the product from the cart, provided with the productID.
	 * 
	 * @param productID
	 *            unique for each product.
	 */
	@Override
	public void removeCart(int productID) {
		try {
			String sql = "delete from cartTable where productID = ? ";

			jdbcTemplate.update(sql, new Object[] { productID });
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Remove the product from the cart for that particular user(email)
	 * 
	 * @param email
	 *            unique for each customer
	 */
	@Override
	public void removeCartWithEmail(String email) {
		try {
			String sql = "delete from cartTable where email = ? and payment= ? ";

			jdbcTemplate.update(sql, new Object[] { email, false });
			System.out.println("remove cart wiht email");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public CartRowMapper getCartRowMapper() {
		return (CartRowMapper) context.getBean("cartRowMapper");
	}

	@SuppressWarnings("unchecked")
	public List<Cart> getCartList() {
		return (List<Cart>) context.getBean("cartList");
	}
}
