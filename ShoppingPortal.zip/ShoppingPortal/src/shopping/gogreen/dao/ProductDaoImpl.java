package shopping.gogreen.dao;

import java.sql.Blob;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Products;
import shopping.gogreen.jdbc.ImageRowMapper;
import shopping.gogreen.jdbc.ProductRowMapper;

/**
 * ProductDaoImpl.java : In this class, the methods of ProductDao interface are
 * implemented.
 */

public class ProductDaoImpl implements ProductDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	WebApplicationContext context;

	/**
	 * Get the total productsList from the database.
	 * 
	 * @return List of products
	 */
	@Override
	public List<Products> getProductsList() {
		List<Products> productsList = getProductList();
		try {
			String sql = "select * from productTable";

			productsList = jdbcTemplate.query(sql, getProductRowMapper());

			return productsList;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	/**
	 * Get the single productDetails provided the ProductID
	 * 
	 * @param productID
	 *            Unique for each product.
	 * @return Product Object that contain the details of the product.
	 */

	@Override
	public Products getSingleProductDetails(int productID) {
		try {
			String sql = "select * from productTable where productID = ? ";
			List<Products> productsList = getProductList();
			productsList = jdbcTemplate.query(sql, new Object[] { productID }, getProductRowMapper());
			return productsList.get(0);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}

	}

	/**
	 * It will increase the quantity of the Product provided the productID.
	 * 
	 * @param productID
	 *            unique for each product
	 */

	@Override
	public void increaseQuantity(int productID) {

		String sql = "UPDATE producttable SET quantity=quantity+1 WHERE productID = ?";

		jdbcTemplate.update(sql, new Object[] { productID });
	}

	/**
	 * Get the count of total number of products present in the database.
	 * 
	 * @param productID
	 *            unique for each product
	 * @return int the total number of products present in the database for that
	 *         product.
	 */

	@Override
	public int getQuantity(int productID) {

		try {
			String sql = "select quantity from productTable where productID=  ? ";

			int q = (int) jdbcTemplate.queryForObject(sql, new Object[] { productID }, int.class);
			return q;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return 0;
		}

	}

	/**
	 * Decrease the quantity of the product by one, provided the product ID.
	 * 
	 * @param productID
	 *            unique for each product
	 * @return {@code true} if quantity i decreased. {@code false} if not.
	 */
	@Override
	public boolean decreaseQuantity(int productID) {
		try {
			String sql = "select quantity from producttable where productID=  ? ";
			int q;
			q = (int) jdbcTemplate.queryForObject(sql, new Object[] { productID }, int.class);
			if (q == 1) {
				sql = "update carttable set payment = ? where productID= ?";
				jdbcTemplate.update(sql, new Object[] { false, productID });
			}
			if (q > 0) {
				sql = "UPDATE producttable SET quantity=quantity-1 WHERE productID = ?";
				jdbcTemplate.update(sql, new Object[] { productID });
				return true;
			} else {
				return false;
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}

	}

	/**
	 * Get the total products present in that category.
	 * 
	 * @param category
	 *            get all product of that category.
	 * @return List of products.
	 */
	@Override
	public List<Products> getCategoryList(String category) {
		try {
			List<Products> productsList = getProductList();
			String sql = "select * from productTable where category= ? ";
			productsList = jdbcTemplate.query(sql, new Object[] { category }, getProductRowMapper());
			return productsList;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	/**
	 * search for the String provided as the parameter, in the database
	 * 
	 * @param search
	 *            the text that the user is searching for.
	 * @return List of products having product name that matches with the text.
	 */
	@Override
	public List<Products> search(String search) {
		try {
			List<Products> productList = getProductList();
			search = "%" + search + "%";
			String sql = "select * from productTable where productName like ? ";
			productList = jdbcTemplate.query(sql, new Object[] { search }, getProductRowMapper());
			return productList;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}

	/**
	 * To get the Image from the database, provided the productID
	 * 
	 * @param productID
	 *            unique for each product
	 * @return Blob product image from the database.
	 */
	@Override
	public Blob getImage(int productID) {

		try {
			Blob blob;
			Products products;
			String sql = "select image from productTable where productID = ? ";
			products = jdbcTemplate.queryForObject(sql, new Object[] { productID }, getImageRowMapper());
			blob = products.getImageName();

			return blob;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}

	}

	/**
	 * returns the List of productID's of all the products.
	 * 
	 * @return List of ProductID's
	 */

	@Override
	public List<Integer> getProductsId() {
		List<Integer> IdList = new ArrayList<Integer>();
		String sql = "select productID from producttable ";
		IdList = jdbcTemplate.queryForList(sql, int.class);
		return IdList;

	}

	@SuppressWarnings("unchecked")
	public List<Products> getProductList() {
		return (List<Products>) context.getBean("productList");
	}

	public ProductRowMapper getProductRowMapper() {
		return (ProductRowMapper) context.getBean("productRowMapper");
	}

	public ImageRowMapper getImageRowMapper() {
		return (ImageRowMapper) context.getBean("imageRowMapper");
	}
}
