package shopping.gogreen.domain;

import java.sql.Blob;

/**
 * Products.java : The instance variables and its corresponding getter and
 * setter methods are declared.
 */
public class Products {

	private int productID;
	private String productName;
	private String category;
	private int quantity;
	private float price;
	private int discount;
	private String plantHabit;
	private String lifeCycle;
	private String sunRequirements;
	private String season;
	private String growthType;
	private String plantHeight;
	private String uses;
	private String color;
	private Blob imageName;
	private String Description;

	/**
	 * @return the productID
	 */
	public int getProductID() {
		return productID;
	}

	/**
	 * @param productID
	 *            the productID to set
	 */
	public void setProductID(int productID) {
		this.productID = productID;
	}

	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * @param productName
	 *            the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}

	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}

	/**
	 * @param category
	 *            the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}

	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity
	 *            the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the price
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(float price) {
		this.price = price;
	}

	/**
	 * @return the discount
	 */
	public int getDiscount() {
		return discount;
	}

	/**
	 * @param discount
	 *            the discount to set
	 */
	public void setDiscount(int discount) {
		this.discount = discount;
	}

	/**
	 * @return the plantHabit
	 */
	public String getPlantHabit() {
		return plantHabit;
	}

	/**
	 * @param plantHabit
	 *            the plantHabit to set
	 */
	public void setPlantHabit(String plantHabit) {
		this.plantHabit = plantHabit;
	}

	/**
	 * @return the lifeCycle
	 */
	public String getLifeCycle() {
		return lifeCycle;
	}

	/**
	 * @param lifeCycle
	 *            the lifeCycle to set
	 */
	public void setLifeCycle(String lifeCycle) {
		this.lifeCycle = lifeCycle;
	}

	/**
	 * @return the sunRequirements
	 */
	public String getSunRequirements() {
		return sunRequirements;
	}

	/**
	 * @param sunRequirements
	 *            the sunRequirements to set
	 */
	public void setSunRequirements(String sunRequirements) {
		this.sunRequirements = sunRequirements;
	}

	/**
	 * @return the season
	 */
	public String getSeason() {
		return season;
	}

	/**
	 * @param season
	 *            the season to set
	 */
	public void setSeason(String season) {
		this.season = season;
	}

	/**
	 * @return the growthType
	 */
	public String getGrowthType() {
		return growthType;
	}

	/**
	 * @param growthType
	 *            the growthType to set
	 */
	public void setGrowthType(String growthType) {
		this.growthType = growthType;
	}

	/**
	 * @return the plantHeight
	 */
	public String getPlantHeight() {
		return plantHeight;
	}

	/**
	 * @param plantHeight
	 *            the plantHeight to set
	 */
	public void setPlantHeight(String plantHeight) {
		this.plantHeight = plantHeight;
	}

	/**
	 * @return the uses
	 */
	public String getUses() {
		return uses;
	}

	/**
	 * @param uses
	 *            the uses to set
	 */
	public void setUses(String uses) {
		this.uses = uses;
	}

	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @param color
	 *            the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @return the imageName
	 */
	public Blob getImageName() {
		return imageName;
	}

	/**
	 * @param imageName
	 *            the imageName to set
	 */
	public void setImageName(Blob imageName) {
		this.imageName = imageName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return Description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		Description = description;
	}

}
