package shopping.gogreen.domain;

/**
 * Cart.java : The instance variables and its corresponding getter and setter
 * methods are declared.
 */
public class Cart {

	private int productID;
	private Byte payment;

	/**
	 * @return the productID
	 */
	public int getProductID() {
		return productID;
	}

	/**
	 * @param productID
	 *            the productID to set
	 */
	public void setProductID(int productID) {
		this.productID = productID;
	}

	/**
	 * @return the payment
	 */
	public Byte getPayment() {
		return payment;
	}

	/**
	 * @param payment
	 *            the payment to set
	 */
	public void setPayment(Byte payment) {
		this.payment = payment;
	}

}
