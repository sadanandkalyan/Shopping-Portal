package shopping.gogreen.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Cart;

/**
 * CartRowMapper.java : Maps one row of the resultSet with the cart object.
 */
@Component
public class CartRowMapper implements RowMapper<Cart> {

	/**
	 * Maps one row of the resultSet with the cart object.
	 * 
	 * @param resultSet
	 *            Object passed after executing the Query.
	 * @return Cart Object with the data.
	 */

	@Autowired
	WebApplicationContext context;

	@Override
	public Cart mapRow(ResultSet rs, int arg1) throws SQLException {
		Cart cart = getCart();
		cart.setProductID(rs.getInt("productID"));
		cart.setPayment(rs.getByte("payment"));
		return cart;
	}

	public Cart getCart() {
		return (Cart) context.getBean("cart");
	}

}
