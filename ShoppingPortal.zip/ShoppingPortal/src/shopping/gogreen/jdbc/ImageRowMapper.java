package shopping.gogreen.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Products;

/**
 * ImageRowMapper.java : Maps the resultSet with the ImageExtracter class.
 */
@Component
public class ImageRowMapper implements RowMapper<Products> {

	/**
	 * Maps the resultSet with the ImageExtracter class.
	 * 
	 * @param resultSet
	 *            Object passed after executing the Query.
	 * @return Products Object with the Image.
	 */

	@Autowired
	WebApplicationContext context;

	@Override
	public Products mapRow(ResultSet resultSet, int line) throws SQLException {
		Products product = getProducts();
		product.setImageName(resultSet.getBlob("image"));
		return product;
	}

	public Products getProducts() {
		return (Products) context.getBean("productsRq");
	}
}
