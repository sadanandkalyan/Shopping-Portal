package shopping.gogreen.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Products;

/**
 * ProductRowMapper.java : Maps one row of the resultSet with the product
 * object.
 */
@Component
public class ProductRowMapper implements RowMapper<Products> {

	/**
	 * Maps one row of the resultSet with the product object.
	 * 
	 * @param resultSet
	 *            Object passed after executing the Query.
	 * @return Products Object with the data.
	 */
	@Autowired
	WebApplicationContext context;

	@Override
	public Products mapRow(ResultSet resultSet, int line) throws SQLException {
		Products product = getProducts();
		product.setProductID(resultSet.getInt("productID"));
		product.setProductName(resultSet.getString("productName"));
		product.setCategory(resultSet.getString("category"));
		product.setQuantity(resultSet.getInt("quantity"));
		product.setPrice(resultSet.getFloat("price"));
		product.setDiscount(resultSet.getInt("discount"));
		product.setPlantHabit(resultSet.getString("plantHabit"));
		product.setLifeCycle(resultSet.getString("lifeCycle"));
		product.setSunRequirements(resultSet.getString("sunRequirements"));
		product.setSeason(resultSet.getString("season"));
		product.setGrowthType(resultSet.getString("growthType"));
		product.setPlantHeight(resultSet.getString("plantHeight"));
		product.setUses(resultSet.getString("uses"));
		product.setColor(resultSet.getString("color"));
		product.setDescription(resultSet.getString("description"));
		product.setImageName(resultSet.getBlob("image"));
		return product;
	}

	public Products getProducts() {
		return (Products) context.getBean("products");
	}
}
