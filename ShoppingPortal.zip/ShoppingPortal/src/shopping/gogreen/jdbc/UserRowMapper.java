package shopping.gogreen.jdbc;

import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.User;

/**
 * UserRowMapper.java : Maps one row of the resultSet with the user object.
 */
@Component
public class UserRowMapper implements RowMapper<User> {

	/**
	 * Maps one row of the resultSet with the order object.
	 * 
	 * @param resultSet
	 *            Object passed after executing the Query.
	 * @return User Object with the data.
	 */
	@Autowired
	WebApplicationContext context;

	@Override
	public User mapRow(ResultSet resultSet, int line) throws SQLException {
		User user = getUser();
		user.setEmail(resultSet.getString("email"));
		user.setPassword(resultSet.getString("password"));
		user.setMobile(resultSet.getLong("mobile"));
		user.setCustomerName(resultSet.getString("customerName"));
		user.setSecurityAnswer(resultSet.getString("secAns"));

		Blob salt = resultSet.getBlob("salt");
		int blobLength = (int) salt.length();
		byte[] blobAsBytes = salt.getBytes(1, blobLength);
		user.setSalt(blobAsBytes);

		return user;
	}

	public User getUser() {
		return (User) context.getBean("user");
	}

}
