package shopping.gogreen.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import shopping.gogreen.domain.Order;

/**
 * OrderRowMapper.java :Maps one row of the resultSet with the order object.
 */
@Component
public class OrderRowMapper implements RowMapper<Order> {

	/**
	 * Maps one row of the resultSet with the order object.
	 * 
	 * @param resultSet
	 *            Object passed after executing the Query.
	 * @return Order Object with the data.
	 */
	@Autowired
	WebApplicationContext context;

	@Override
	public Order mapRow(ResultSet resultSet, int line) throws SQLException {
		Order order = getOrder();
		order.setOrderID(resultSet.getInt("orderID"));
		order.setEmail(resultSet.getString("email"));
		order.setProductID(resultSet.getInt("productID"));
		order.setDateOfBooking(resultSet.getString("bookingDate"));
		order.setAmountPaid(resultSet.getFloat("amountPaid"));
		order.setShippingAddress(resultSet.getString("shippingAddress"));
		order.setDeliveryDate(resultSet.getString("deliveryDate"));
		return order;
	}

	public Order getOrder() {
		return (Order) context.getBean("order");
	}
}
